// 📌 DOM Elements
const navbar = document.getElementById('navbar');
const menuToggle = document.getElementById('menu-toggle');
const navLinks = document.getElementById('nav-links');
const toggleMode = document.getElementById('toggle-mode');
const scrollProgress = document.getElementById('scroll-progress');
const sections = document.querySelectorAll("section, header");
const navItems = document.querySelectorAll(".nav-links a");

// 🌙 Toggle Dark/Light Mode
toggleMode.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  toggleMode.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
});

// 📜 Navbar Scroll Background + Scroll Progress + Active Link Highlight
window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;

  // Navbar style change
  if (scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }

  // Scroll progress bar update
  const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  const scrolledPercent = (scrollY / scrollHeight) * 100;
  scrollProgress.style.width = `${scrolledPercent}%`;

  // Active link highlight
  let currentSection = "";
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 100;
    if (scrollY >= sectionTop) {
      currentSection = section.getAttribute("id");
    }
  });

  navItems.forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("href") === `#${currentSection}`) {
      link.classList.add("active");
    }
  });
});

// 🍔 Toggle Mobile Menu
menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

// 🚫 Close mobile menu when a link is clicked
navItems.forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
  });
});
// ✨ Reveal sections on scroll
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll(".content").forEach(section => {
  revealObserver.observe(section);
});
